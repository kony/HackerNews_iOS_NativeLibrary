define({
    appInit: function(params) {
        skinsInit();
        kony.mvc.registry.add("com.konymp.ratingprompt", "ratingprompt", "ratingpromptController");
        kony.application.registerMaster({
            "namespace": "com.konymp",
            "classname": "ratingprompt",
            "name": "com.konymp.ratingprompt"
        });
        kony.mvc.registry.add("flxSampleRowTemplate", "flxSampleRowTemplate", "flxSampleRowTemplateController");
        kony.mvc.registry.add("flxSectionHeaderTemplate", "flxSectionHeaderTemplate", "flxSectionHeaderTemplateController");
        kony.mvc.registry.add("frmRatingPrompt", "frmRatingPrompt", "frmRatingPromptController");
        setAppBehaviors();
    },
    postAppInitCallBack: function(eventObj) {},
    appmenuseq: function() {
        new kony.mvc.Navigation("frmRatingPrompt").navigate();
    }
});