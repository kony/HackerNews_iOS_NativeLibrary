define(function() {
    return function(controller) {
        var ratingprompt = new kony.ui.FlexContainer({
            "clipBounds": true,
            "isMaster": true,
            "height": "100%",
            "id": "ratingprompt",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "skin": "konymprpsknslFbox2",
            "top": "0dp",
            "width": "100%"
        }, {}, {});
        ratingprompt.setDefaultUnit(kony.flex.DP);
        var flxOverlay = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxOverlay",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0%",
            "isModalContainer": false,
            "skin": "konymprpsknFlxOverlay",
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, {}, {});
        flxOverlay.setDefaultUnit(kony.flex.DP);
        var flxRate = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "45.88%",
            "id": "flxRate",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "4.27%",
            "isModalContainer": false,
            "skin": "konymprpsknFlxrate",
            "top": "27.39%",
            "width": "91.47%",
            "zIndex": 1
        }, {}, {});
        flxRate.setDefaultUnit(kony.flex.DP);
        var lblMsg = new kony.ui.Label({
            "centerX": "50%",
            "height": "10%",
            "id": "lblMsg",
            "isVisible": true,
            "left": "26.68%",
            "maxNumberOfLines": 1,
            "skin": "konymprpsknlblMsg",
            "text": "Please rate our App",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "textTruncatePosition": constants.TEXT_TRUNCATE_NONE,
            "top": "18.61%",
            "width": "90%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false
        });
        var flxStar = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "centerX": "50%",
            "clipBounds": true,
            "height": "18%",
            "id": "flxStar",
            "isVisible": true,
            "layoutType": kony.flex.FLOW_HORIZONTAL,
            "left": "20.90%",
            "isModalContainer": false,
            "right": "20.50%",
            "skin": "slFbox",
            "top": "28%",
            "width": "60%",
            "zIndex": 1
        }, {}, {});
        flxStar.setDefaultUnit(kony.flex.DP);
        var flxStar1 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxStar1",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_092c6f66f5404c719cd3567ce28daba1,
            "skin": "slFbox",
            "top": "0dp",
            "width": "20%",
            "zIndex": 1
        }, {}, {});
        flxStar1.setDefaultUnit(kony.flex.DP);
        var imgStar1 = new kony.ui.Image2({
            "height": "100%",
            "id": "imgStar1",
            "isVisible": true,
            "left": "0%",
            "skin": "slImage",
            "src": "konymp_rp03_ico_star_active4.png",
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxStar1.add(imgStar1);
        var flxStar2 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxStar2",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_aa9b69fdb9d14566b243a4efe3f91c7c,
            "skin": "slFbox",
            "top": "0dp",
            "width": "20%",
            "zIndex": 1
        }, {}, {});
        flxStar2.setDefaultUnit(kony.flex.DP);
        var imgStar2 = new kony.ui.Image2({
            "height": "100%",
            "id": "imgStar2",
            "isVisible": true,
            "left": "0%",
            "skin": "slImage",
            "src": "konymp_rp03_ico_star_deact.png",
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxStar2.add(imgStar2);
        var flxStar3 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxStar3",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_68855b4468cb4cb1baee31cfadf9fe9f,
            "skin": "slFbox",
            "top": "0dp",
            "width": "20%",
            "zIndex": 1
        }, {}, {});
        flxStar3.setDefaultUnit(kony.flex.DP);
        var imgStar3 = new kony.ui.Image2({
            "height": "100%",
            "id": "imgStar3",
            "isVisible": false,
            "left": "0%",
            "skin": "slImage",
            "src": "ico_star_deact.png",
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxStar3.add(imgStar3);
        var flxStar4 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxStar4",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_f6d89cfd9807479f9104d7c4395db9d3,
            "skin": "slFbox",
            "top": "0dp",
            "width": "20%",
            "zIndex": 1
        }, {}, {});
        flxStar4.setDefaultUnit(kony.flex.DP);
        var imgStar4 = new kony.ui.Image2({
            "height": "100%",
            "id": "imgStar4",
            "isVisible": false,
            "left": "0%",
            "skin": "slImage",
            "src": "ico_star_deact.png",
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxStar4.add(imgStar4);
        var flxStar5 = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "100%",
            "id": "flxStar5",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "0dp",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_ca5b9e4d3baf40aba92fb9124245ada3,
            "skin": "slFbox",
            "top": "0dp",
            "width": "20%",
            "zIndex": 1
        }, {}, {});
        flxStar5.setDefaultUnit(kony.flex.DP);
        var imgStar5 = new kony.ui.Image2({
            "height": "100%",
            "id": "imgStar5",
            "isVisible": false,
            "left": "0%",
            "skin": "slImage",
            "src": "ico_star_deact.png",
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxStar5.add(imgStar5);
        flxStar.add(flxStar1, flxStar2, flxStar3, flxStar4, flxStar5);
        var lblDesc = new kony.ui.Label({
            "centerX": "50%",
            "height": "20%",
            "id": "lblDesc",
            "isVisible": true,
            "left": "17.87%",
            "skin": "konymprpsknLblDesc",
            "text": "If you enjoy using AppName, would you mind taking a moment to rate it? Thanks for your support!",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "top": "44.48%",
            "width": "69.53%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false
        });
        var lbl1 = new kony.ui.Label({
            "height": "1dp",
            "id": "lbl1",
            "isVisible": true,
            "left": "0dp",
            "skin": "konymprpsknlblLine",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "top": "77.12%",
            "width": "100%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false
        });
        var lbl2 = new kony.ui.Label({
            "centerX": "50%",
            "height": "22.60%",
            "id": "lbl2",
            "isVisible": true,
            "left": "10dp",
            "skin": "konymprpsknlblLine",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "top": "77.45%",
            "width": "1dp",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false
        });
        var txtFeedback = new kony.ui.TextArea2({
            "autoCapitalize": constants.TEXTAREA_AUTO_CAPITALIZE_NONE,
            "focusSkin": "konymprpsknTextAreaFocus",
            "height": "40.20%",
            "id": "txtFeedback",
            "isVisible": false,
            "keyBoardStyle": constants.TEXTAREA_KEY_BOARD_STYLE_DEFAULT,
            "left": "5.23%",
            "numberOfVisibleLines": 3,
            "onTextChange": controller.AS_TextArea_dfdb456220b34d8f87e037d1d7b0ad72,
            "placeholder": "Enter your message",
            "right": "5.23%",
            "skin": "konymprpskntxtFeedback",
            "textInputMode": constants.TEXTAREA_INPUT_MODE_ANY,
            "top": "31.05%",
            "zIndex": 4
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_TOP_LEFT,
            "padding": [2, 2, 2, 2],
            "paddingInPixel": false
        }, {});
        var flxDismiss = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "17%",
            "id": "flxDismiss",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "2.03%",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_975edc50a86d42ee8ae015d17252e8ab,
            "skin": "slFbox",
            "top": "80%",
            "width": "46.01%",
            "zIndex": 2
        }, {}, {});
        flxDismiss.setDefaultUnit(kony.flex.DP);
        var lblDismiss = new kony.ui.Label({
            "height": "100%",
            "id": "lblDismiss",
            "isVisible": true,
            "left": "0%",
            "skin": "konymprpsknlblDismiss",
            "text": "Dismiss",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "top": "0%",
            "width": "100%",
            "zIndex": 2
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false
        });
        var lblOK = new kony.ui.Label({
            "height": "100%",
            "id": "lblOK",
            "isVisible": false,
            "left": "0%",
            "skin": "konymprpsknlblDismiss",
            "text": "OK",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "top": "0%",
            "width": "100%",
            "zIndex": 2
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false
        });
        flxDismiss.add(lblDismiss, lblOK);
        var flxSubmit = new kony.ui.FlexContainer({
            "autogrowMode": kony.flex.AUTOGROW_NONE,
            "clipBounds": true,
            "height": "17%",
            "id": "flxSubmit",
            "isVisible": true,
            "layoutType": kony.flex.FREE_FORM,
            "left": "52.48%",
            "isModalContainer": false,
            "onClick": controller.AS_FlexContainer_0a4cb74ad24442f79326229f7b72599c,
            "skin": "slFbox",
            "top": "80%",
            "width": "46.01%",
            "zIndex": 2
        }, {}, {});
        flxSubmit.setDefaultUnit(kony.flex.DP);
        var lblSubmit = new kony.ui.Label({
            "height": "100%",
            "id": "lblSubmit",
            "isVisible": true,
            "left": "0%",
            "skin": "konymprpsknLblSubmit",
            "text": "Submit",
            "textStyle": {
                "letterSpacing": 0,
                "strikeThrough": false
            },
            "top": "0%",
            "width": "100%",
            "zIndex": 1
        }, {
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "textCopyable": false
        });
        flxSubmit.add(lblSubmit);
        flxRate.add(lblMsg, flxStar, lblDesc, lbl1, lbl2, txtFeedback, flxDismiss, flxSubmit);
        var imgLogo = new kony.ui.Image2({
            "height": "13.79%",
            "id": "imgLogo",
            "isVisible": true,
            "left": "37.87%",
            "skin": "slImage",
            "src": "konymp_rp03_app_icon.png",
            "top": "20.39%",
            "width": "24.53%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        var imgCompletion = new kony.ui.Image2({
            "height": "13.79%",
            "id": "imgCompletion",
            "isVisible": false,
            "left": "37.87%",
            "skin": "slImage",
            "src": "konymp_rp03_ico_group.png",
            "top": "20.39%",
            "width": "24.53%",
            "zIndex": 1
        }, {
            "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {});
        flxOverlay.add(flxRate, imgLogo, imgCompletion);
        ratingprompt.add(flxOverlay);
        return ratingprompt;
    }
})