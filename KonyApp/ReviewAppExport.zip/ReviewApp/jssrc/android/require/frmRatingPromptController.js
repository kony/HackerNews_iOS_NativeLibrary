define("userfrmRatingPromptController", {
    //Type your controller code here 
});
define("frmRatingPromptControllerActions", {
    /*
      This is an auto generated file and any modifications to it may result in corruption of the action sequence.
    */
    /** onDismiss defined for ratingprompt **/
    AS_UWI_ec263bbb97504407851b82c4ad7953a8: function AS_UWI_ec263bbb97504407851b82c4ad7953a8() {
        var self = this;
        this.view.ratingprompt.isVisible = false;
    },
    /** onCompletion defined for ratingprompt **/
    AS_UWI_d4a5afa3b5f748dcb89d100cf49735af: function AS_UWI_d4a5afa3b5f748dcb89d100cf49735af() {
        var self = this;
        this.view.ratingprompt.isVisible = false;
    },
    /** postShow defined for frmRatingPrompt **/
    AS_Form_de5e122c7db2423dbfafc1dd9147a24a: function AS_Form_de5e122c7db2423dbfafc1dd9147a24a(eventobject) {
        var self = this;
        this.view.ratingprompt.invokeRatingPrompt();
    }
});
define("frmRatingPromptController", ["userfrmRatingPromptController", "frmRatingPromptControllerActions"], function() {
    var controller = require("userfrmRatingPromptController");
    var controllerActions = ["frmRatingPromptControllerActions"];
    for (var i = 0; i < controllerActions.length; i++) {
        var actions = require(controllerActions[i]);
        for (var key in actions) {
            controller[key] = actions[key];
        }
    }
    return controller;
});
