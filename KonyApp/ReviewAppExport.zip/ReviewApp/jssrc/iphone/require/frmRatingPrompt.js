define("frmRatingPrompt", function() {
    return function(controller) {
        function addWidgetsfrmRatingPrompt() {
            this.setDefaultUnit(kony.flex.DP);
            var ratingprompt = new com.konymp.ratingprompt({
                "clipBounds": true,
                "height": "100%",
                "id": "ratingprompt",
                "isVisible": true,
                "layoutType": kony.flex.FREE_FORM,
                "left": "0dp",
                "masterType": constants.MASTER_TYPE_USERWIDGET,
                "isModalContainer": false,
                "skin": "konymprpsknslFbox2",
                "top": "0dp",
                "width": "100%"
            }, {}, {});
            ratingprompt.thankyouMessage = "Thank You for your valuable rating.";
            ratingprompt.rateMessage = "If you enjoy using the app, would you mind taking a moment to rate it? Thanks for your support!";
            ratingprompt.rateTitle = "Please Rate our App";
            ratingprompt.isFeedbackEnabled = true;
            ratingprompt.onDismiss = controller.AS_UWI_ec263bbb97504407851b82c4ad7953a8;
            ratingprompt.onCompletion = controller.AS_UWI_d4a5afa3b5f748dcb89d100cf49735af;
            this.add(ratingprompt);
        };
        return [{
            "addWidgets": addWidgetsfrmRatingPrompt,
            "enabledForIdleTimeout": false,
            "id": "frmRatingPrompt",
            "layoutType": kony.flex.FREE_FORM,
            "needAppMenu": false,
            "postShow": controller.AS_Form_de5e122c7db2423dbfafc1dd9147a24a,
            "skin": "slForm"
        }, {
            "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
            "layoutType": kony.flex.FREE_FORM,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false
        }, {
            "configureExtendBottom": false,
            "configureExtendTop": false,
            "configureStatusBarStyle": false,
            "footerOverlap": false,
            "formTransparencyDuringPostShow": "100",
            "headerOverlap": false,
            "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_CANCEL,
            "needsIndicatorDuringPostShow": false,
            "retainScrollPosition": false,
            "titleBar": false,
            "titleBarSkin": "slTitleBar"
        }]
    }
});