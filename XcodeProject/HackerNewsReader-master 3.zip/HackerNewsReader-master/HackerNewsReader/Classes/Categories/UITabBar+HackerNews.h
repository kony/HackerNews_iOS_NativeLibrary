//
//  UITabBar+HackerNews.h
//  HackerNewsReader
//
//  Created by Ryan Nystrom on 1/6/16.
//  Copyright © 2016 Ryan Nystrom. All rights reserved.
//

@import UIKit;

NS_ASSUME_NONNULL_BEGIN

@interface UITabBar (HackerNews)

+ (void)hn_enableAppearance;

@end

NS_ASSUME_NONNULL_END
