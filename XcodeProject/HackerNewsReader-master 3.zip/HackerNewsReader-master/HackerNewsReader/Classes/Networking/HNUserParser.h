//
//  HNUserParser.h
//  HackerNewsNetworker
//
//  Created by Ryan Nystrom on 1/31/16.
//  Copyright © 2016 Ryan Nystrom. All rights reserved.
//

@import Foundation;

#import "HNParseProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface HNUserParser : NSObject <HNParseProtocol>

@end

NS_ASSUME_NONNULL_END
