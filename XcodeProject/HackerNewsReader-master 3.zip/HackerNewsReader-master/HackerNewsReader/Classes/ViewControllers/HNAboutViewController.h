//
//  HNAboutViewController.h
//  HackerNewsReader
//
//  Created by Ryan Nystrom on 2/2/16.
//  Copyright © 2016 Ryan Nystrom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HNAboutViewController : UIViewController

@property (nonatomic, copy) NSString *aboutText;

@end
