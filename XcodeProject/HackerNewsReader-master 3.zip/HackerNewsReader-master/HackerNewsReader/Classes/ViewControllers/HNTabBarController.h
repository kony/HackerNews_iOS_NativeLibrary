//
//  HNTabBarController.h
//  HackerNewsReader
//
//  Created by Ryan Nystrom on 1/6/16.
//  Copyright © 2016 Ryan Nystrom. All rights reserved.
//

@import UIKit;

@interface HNTabBarController : UITabBarController

@end
