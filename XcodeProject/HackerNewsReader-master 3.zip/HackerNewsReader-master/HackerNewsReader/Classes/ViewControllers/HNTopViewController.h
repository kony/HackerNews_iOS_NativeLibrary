//
//  HNTopViewController.h
//  HackerNewsReader
//
//  Created by Ryan Nystrom on 6/6/15.
//  Copyright (c) 2015 Ryan Nystrom. All rights reserved.
//

@import UIKit;

#import <CoreComponent/KonyLibrary.h>
#import "HNFeedViewController.h"

NS_ASSUME_NONNULL_BEGIN

@interface HNTopViewController : HNFeedViewController <KonyLibraryInitializationDelegate, KonyLibraryResultDelegate>

@end

NS_ASSUME_NONNULL_END
