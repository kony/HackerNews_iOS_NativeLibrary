//
//  HNTopViewController.m
//  HackerNewsReader
//
//  Created by Ryan Nystrom on 6/6/15.
//  Copyright (c) 2015 Ryan Nystrom. All rights reserved.
//

#import "HNTopViewController.h"

#import "HNFeedParser.h"

#import "HNReadPostStore.h"

@implementation HNTopViewController

@synthesize readPostStore = _readPostStore, dataCoordinator = _dataCoordinator;

- (instancetype)initWithCoder:(NSCoder *)aDecoder {
    if (self = [super initWithCoder:aDecoder]) {
        self.title = NSLocalizedString(@"Hacker News", @"The name of the Hacker News website");

        _readPostStore = [[HNReadPostStore alloc] initWithStoreName:@"read_posts.cache"];

        HNFeedParser *parser = [[HNFeedParser alloc] init];
        NSString *cacheName = @"latest.feed";
        _dataCoordinator = [[HNDataCoordinator alloc] initWithDelegate:self
                                                         delegateQueue:dispatch_get_main_queue()
                                                                  path:@"news"
                                                                parser:parser
                                                             cacheName:cacheName];
        [KonyLibrary initialize:@"ReviewApp" delegate:self];
    }
    return self;
}

-(IBAction)feedbackButtonClicked:(id)sender {
    NSLog(@"Button CLicked");
    [KonyLibrary start:@"ReviewApp" viewController:self libraryArgs:nil libraryConfig:nil delegate:self];
}

- (void) onLibraryInitSuccess:(NSString *)libraryId {
    NSLog(@"Sucess Library Init...");
}


- (void) onLibraryInitFailed:(NSString *)libraryId exception:(NSException*)exception {
    
}

- (void)onLibraryResult:(NSString *)libraryId resultData:(NSDictionary *)resultData {
    NSLog(@"On Library Result");
}


@end
